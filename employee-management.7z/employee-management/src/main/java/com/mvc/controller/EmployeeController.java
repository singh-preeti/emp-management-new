package com.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mvc.model.Employee;
import com.mvc.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	private EmployeeService empService;
	
	//Get(read),Post(create/add),Put(update),Delete
//	@GetMapping("/get")
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addAll(@RequestBody Employee employee)
	{
		return ResponseEntity.ok(empService.save(employee));
		
	}
	
//	@PutMapping("/update")
//	@DeleteMapping("/{id}")

}
